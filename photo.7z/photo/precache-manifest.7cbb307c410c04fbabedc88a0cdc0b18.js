self.__precacheManifest = [
  {
    "revision": "a1165cf06c7d5191baf6a0492016da38",
    "url": "/photo/static/media/tk.a1165cf0.png"
  },
  {
    "revision": "d638a50b4ffccb937058",
    "url": "/photo/static/js/runtime~main.d638a50b.js"
  },
  {
    "revision": "ce5c7820313dd51a2d7b",
    "url": "/photo/static/js/main.ce5c7820.chunk.js"
  },
  {
    "revision": "cbc0519caa910ccb94e7",
    "url": "/photo/static/js/1.cbc0519c.chunk.js"
  },
  {
    "revision": "ce5c7820313dd51a2d7b",
    "url": "/photo/static/css/main.ee9e817f.chunk.css"
  },
  {
    "revision": "72b6f6bb1cf225fa5b5b488c0f8f1a31",
    "url": "/photo/index.html"
  }
];